This is OpenNL Pluggable Software Module, extracted
from GEOGRAM source tree. It contains a standalone .cpp/.h
pair that can be used in any program and that does not have
any dependency. 

It may also contain an example program that can be compiled by using:
  g++ --std=c++11 OpenNL_psm.cpp OpenNL_example.cpp -o OpenNL_example
(or gcc if it is plain C, as in OpenNL)

Some examples may require additional compilation flags (see comments at the beginning
of the example source, e.g. Delaunay_example.cpp).
